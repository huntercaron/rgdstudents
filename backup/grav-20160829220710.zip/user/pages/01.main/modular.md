---
title: main
content:
    items: '@self.modular'
    order:
        by: default
        dir: asc
        custom:
            - _hero
            - _nope
            - _shit
            - _text
body_classes: modular
---

